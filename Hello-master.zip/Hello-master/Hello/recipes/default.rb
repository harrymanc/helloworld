#
# Cookbook Name:: Hello
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
file '/tmp/helloworld.txt' do
  content 'hello world'
end
