# hello-world
devops project
comcast-test Build Status

Assignment

Used Ruby Language, Chef, Amazon web services and Git to complete the assignment. 

Wrote Chef recipies on AWS EC2 INSTANCE to achieve the HELLO WORLD!
Wrote sample code's to display "Hello World" using ruby, extended ruby and HTML in chef cookbook. 
Using amazon web sevices achieved Load Balancing, auto scaling and Deployment of the cookbooks on to the EC2 instance. 
Used Github repository to store the chef cookbooks. 
